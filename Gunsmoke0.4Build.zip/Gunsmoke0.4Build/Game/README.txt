***Gunsmoke 0.4***

-Added ModuleCollision.
-No longer can move the camera in x axis.
-No more parallax.
-Enemy created.
-Collision boxes on buildings, player, enemy and bullets.


