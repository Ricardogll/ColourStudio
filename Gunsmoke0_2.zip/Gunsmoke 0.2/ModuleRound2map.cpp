#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound2map.h"



ModuleRound2map::ModuleRound2map()
{

	//mapRound2
	map2.x = 0;
	map2.y = 0;
	map2.w = 224;
	map2.h = 3200;


}

ModuleRound2map::~ModuleRound2map()
{
}


bool ModuleRound2map::Start()
{
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("GunSmoke-Round2.png");
	return ret;
}


update_status ModuleRound2map::Update()
{
	App->render->Blit(graphics, 0, -3200 + SCREEN_HEIGHT + 130, &map2, 5.5f);
	return UPDATE_CONTINUE;
}
