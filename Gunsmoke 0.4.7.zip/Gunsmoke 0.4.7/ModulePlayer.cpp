#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include"ModuleCollision.h"
#include"ModuleFadeToBlack.h"
#include"ModuleRound1map.h"
#include"ModuleEndImg.h"
#include "SDL\include\SDL_timer.h"
// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA
Collider* playercoll;

ModulePlayer::ModulePlayer()
{
	graphics = NULL;
	current_animation = NULL;

	position.x = 0;
	position.y = 0;

	// idle animation (just the ship)
	idle.PushBack({ 95, 0, 20, 27 });
	idle.PushBack({ 55, 0, 20, 27 });
	idle.PushBack({ 15, 0, 20, 27 });
	idle.PushBack({ 55, 0, 20, 27 });
	idle.PushBack({ 95, 0, 20, 27 });
	idle.PushBack({ 134, 0, 20, 27 });
	idle.PushBack({ 175, 0, 20, 27 });
	idle.loop = true;
	idle.speed = 0.075f;

	// move upwards
	up.PushBack({ 95, 0, 20, 27 });
	up.PushBack({ 55, 0, 20, 27 });
	up.PushBack({ 15, 0, 20, 27 });
	up.PushBack({ 55, 0, 20, 27 });
	up.PushBack({ 95, 0, 20, 27 });
	up.PushBack({ 134, 0, 20, 27 });
	up.PushBack({ 175, 0, 20, 27 });
	up.loop = true;
	up.speed = 0.1f;

	// Move down
	down.PushBack({ 95, 0, 20, 27 });
	down.PushBack({ 55, 0, 20, 27 });
	down.PushBack({ 15, 0, 20, 27 });
	down.PushBack({ 55, 0, 20, 27 });
	down.PushBack({ 95, 0, 20, 27 });
	down.PushBack({ 134, 0, 20, 27 });
	down.PushBack({ 175, 0, 20, 27 });
	down.loop = true;
	down.speed = 0.1f;

	right.PushBack({ 17,39,20,27 });//1 12321454
	right.PushBack({ 56,39,20,27 });//2
	right.PushBack({ 94,39,20,27 });//3
	right.PushBack({ 56,39,20,27 });//2
	right.PushBack({ 17,39,20,27 });//1
	right.PushBack({ 457,0,20,27 });//4
	right.PushBack({ 417,0,20,27 });//5
	right.PushBack({ 457,0,20,27 });//4
	right.loop = true;
	right.speed = 0.1f;

	left.PushBack({ 456,200,20,27 });
	left.PushBack({ 416,200,20,27 });
	left.PushBack({ 374,200,20,27 });
	left.PushBack({ 416,200,20,27 });
	left.PushBack({ 456,200,20,27 });
	left.PushBack({ 16,160,20,27 });
	left.PushBack({ 55,160,20,27 });
	left.PushBack({ 16,160,20,27 });
	left.loop = true;
	left.speed = 0.1f;

	shootup.PushBack({ 295,0,20,27 });
	shootup.PushBack({ 255,0,20,27 });
	shootup.PushBack({ 215,0,20,27 });
	shootup.PushBack({ 255,0,20,27 });
	shootup.PushBack({ 295,0,20,27 });
	shootup.PushBack({ 335,0,20,27 });
	shootup.PushBack({ 375,0,20,27 });
	shootup.PushBack({ 335,0,20,27 });
	shootup.loop = true;
	shootup.speed = 0.1f;

	shootright.PushBack({ 217,39,20,27 });
	shootright.PushBack({ 177,39,20,27 });
	shootright.PushBack({ 137,39,20,27 });
	shootright.PushBack({ 177,39,20,27 });
	shootright.PushBack({ 217,39,20,27 });
	shootright.PushBack({ 257,39,20,27 });
	shootright.PushBack({ 297,39,20,27 });
	shootright.PushBack({ 257,39,20,27 });
	shootright.loop = true;
	shootright.speed = 0.1f;

	shootleft.PushBack({ 254,200,20,27 });
	shootleft.PushBack({ 294,200,20,27 });
	shootleft.PushBack({ 334,200,20,27 });
	shootleft.PushBack({ 294,200,20,27 });
	shootleft.PushBack({ 254,200,20,27 });
	shootleft.PushBack({ 214,200,20,27 });
	shootleft.PushBack({ 174,200,20,27 });
	shootleft.PushBack({ 214,200,20,27 });
	shootleft.loop = true;
	shootleft.speed = 0.1f;


}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	LOG("Loading player");

	graphics = App->textures->Load("gunsmoke/Gunman.png");
	position.x = SCREEN_WIDTH/2;
	position.y = SCREEN_HEIGHT-100;
	playercoll = App->collision->AddCollider({ position.x,position.y,20,27 }, COLLIDER_PLAYER, this);
	destroyed = false;

	return true;
}

// Unload assets
bool ModulePlayer::CleanUp()
{
	LOG("Unloading player");

	App->textures->Unload(graphics);
	if (playercoll != nullptr)
		playercoll->to_delete = true;

	return true;
}

// Update: draw background
update_status ModulePlayer::Update()
{
	int speed = 1;
	

	if ((App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_REPEAT) || (App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_REPEAT) || (App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_REPEAT)) {
		if (App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_REPEAT) {
			if (current_animation != &shootup)
			{
				shootup.Reset();
				current_animation = &shootup;
				
			}
		}
		if (App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_REPEAT) {
			if (current_animation != &shootleft)
			{
				shootleft.Reset();
				current_animation = &shootleft;

			}
		}
		if (App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_REPEAT) {
			if (current_animation != &shootright)
			{
				shootright.Reset();
				current_animation = &shootright;

			}
		}
		gate = false;
		lastTime = SDL_GetTicks();
	}

	if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE)
	{
		position.x -= speed;
		if (current_animation != &left && gate==true)
		{
			left.Reset();
			current_animation = &left;
		}
		if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
			position.y -= speed;
		if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
			position.y += speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE)
	{
		position.x += speed;
		if (current_animation != &right && gate==true)
		{
			right.Reset();
			current_animation = &right;
		}
		if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
			position.y -= speed;
		if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
			position.y += speed;
	}

	if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE &&App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE) {
		position.y -= speed;
		if (current_animation != &up && gate==true)
		{ 
			up.Reset();
			current_animation = &up;
		}
	}

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT && App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE &&App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE) {
		position.y += speed;
		if (current_animation != &down && gate == true)
		{
			down.Reset();
			current_animation = &down;
		}
	}

	

	if ((App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_REPEAT || App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_DOWN) && shooting_speed1 <= 20) {
		shooting_speed1++;
		if (shooting_speed1 == 20 || App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_DOWN) {
			App->particles->AddParticle(App->particles->laser, position.x + 1, position.y, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			App->particles->AddParticle(App->particles->laser, position.x + 16, position.y, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			shooting_speed1 = 0;

		}
	}

	if ((App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_REPEAT || App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_DOWN) && shooting_speed2 <= 20) {
		shooting_speed2++;
		if (shooting_speed2 == 20 || App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_DOWN) {
			App->particles->AddParticle(App->particles->laserright1, position.x + 10, position.y + 10, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			App->particles->AddParticle(App->particles->laserright2, position.x + 5, position.y + 5, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			shooting_speed2 = 0;
		}

	}

	if ((App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_REPEAT || App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_DOWN) && shooting_speed3 <= 20) {
		shooting_speed3++;
		if (shooting_speed3 == 20 || App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_DOWN) {
			App->particles->AddParticle(App->particles->laserleft1, position.x, position.y + 10, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			App->particles->AddParticle(App->particles->laserleft2, position.x + 5, position.y + 5, COLLIDER_PLAYER_SHOT, PARTICLE_PLAYER_SHOT);
			shooting_speed3 = 0;
		}
	}
	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE
		&& App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_IDLE &&
		App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE&&
		App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE&&
		App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_IDLE&&
		App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_IDLE&&
		App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_IDLE&& gate==true)
		current_animation = &idle;

	
	// Draw everything --------------------------------------
	playercoll->rect.x = position.x;
	playercoll->rect.y = position.y;

	if(destroyed==false)
		App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	if ((App->input->keyboard[SDL_SCANCODE_J] == KEY_STATE::KEY_UP) || (App->input->keyboard[SDL_SCANCODE_K] == KEY_STATE::KEY_UP) || (App->input->keyboard[SDL_SCANCODE_L] == KEY_STATE::KEY_UP)) {
		
		
		if (gate2 == true) {
			lastTime = SDL_GetTicks();
			gate2 = false;
		}


		/*currentTime = SDL_GetTicks();
		if (currentTime > lastTime + 10) {
			gate = true;
			gate2 = true;
			lastTime = currentTime;
		}*/
		

	}
	currentTime = SDL_GetTicks();
	if (currentTime > lastTime + 1000) {
		gate = true;
		gate2 = true;
		lastTime = currentTime;
	}

	return UPDATE_CONTINUE;
}

void ModulePlayer::OnCollision(Collider* c1, Collider* c2) {
	//poner explosiones/ir a pagina principal
	
	//si choca con enemigo
	if (c2->type==COLLIDER_ENEMY && destroyed == false && App->fade->IsFading() == false) {
		destroyed = true;
		App->fade->FadeToBlack(App->Maps1, App->endimg);
		App->collision->Disable();
	}

	//si choca con una pared
	if (c2->type == COLLIDER_WALL && destroyed == false && App->fade->IsFading() == false) {
		

	
		if (c1->rect.y < c2->rect.y + c2->rect.h && c1->rect.y + 3 > c2->rect.y + c2->rect.h)
			
		{
			position.y = position.y + 1;
		
		}
		else if (c1->rect.y + c1->rect.h > c2->rect.y && c1->rect.y + c1->rect.h - 3< c2->rect.y)
			
		{
			position.y = position.y - 1;
		
		}

		
		else if (c1->rect.x + c1->rect.w > c2->rect.x && c1->rect.x + c1->rect.w - 3 < c2->rect.x)
		{
			position.x = position.x - 1;
			
		}
		else if (c1->rect.x < c2->rect.x + c2->rect.w && c1->rect.x + 3 > c2->rect.x + c2->rect.w)
		{
			position.x = position.x + 1;
			
		}
		
	}
	
}


