
#ifndef __ENEMY_H__
#define __ENEMY_H__

#include "p2Point.h"
#include "Animation.h"
#include "Path.h"

struct SDL_Texture;
struct Collider;

class Enemy
{
protected:
	
	Collider* collider = nullptr;
	Path* path;

public:
	Animation* animation = nullptr;
	iPoint position;
	bool dead_enemy = false;
	Animation front;
	Animation right;
	Animation left;
	Animation back;
	Animation upright;
	Animation upleft;
	Animation downright;
	Animation downleft;
	Animation dead;
	

public:
	Enemy(int x, int y);
	virtual ~Enemy();

	const Collider* GetCollider() const;

	virtual void Move() {};
	virtual void Draw(SDL_Texture* sprites);
	virtual void OnCollision(Collider* collider);
	//virtual void OnCollision(Collider* c1, Collider* c2);
	virtual void Shoot() {};
	float to_degrees(float num);
};

#endif // __ENEMY_H__
