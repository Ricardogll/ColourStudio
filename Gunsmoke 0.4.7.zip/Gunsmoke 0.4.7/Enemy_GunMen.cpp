#include "Application.h"
#include "Enemy_GunMen.h"
#include "ModuleCollision.h"
#include"Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"

#define ENEMY_SHOOTING_SPEED 3000
#define ENEMY_SHOT_SPEED 3.0f


Enemy_GunMen::Enemy_GunMen(int x, int y) :Enemy(x, y) {

	//angles=DistanceAngles(...
	front.PushBack({ 255,51,24,29 });
	front.PushBack({ 215, 51, 24, 29 });
	front.PushBack({ 255,51,24,29 });
	front.PushBack({ 295, 51, 24, 29 });
	front.speed = 0.1f;

	//animation = &front;			//dependiendo del angulo con el jugador usar una animacion u otra

	right.PushBack({ 18,51,24,29 });
	right.PushBack({ 57,51,24,29 });
	right.PushBack({ 18,51,24,29 });
	right.PushBack({ 337,11,24,29 });
	right.speed = 0.1f;


	left.PushBack({ 132,91,24,29 });
	left.PushBack({ 171,91,24,29 });
	left.PushBack({ 132,91,24,29 });
	left.PushBack({ 93,91,24,29 });
	left.speed = 0.1f;

	//animation = &front;    //??????????????

	upright.PushBack({ 258, 11, 24, 29 });
	upright.PushBack({ 297, 11, 24, 29 });
	upright.PushBack({ 258, 11, 24, 29 });
	upright.PushBack({ 97, 11, 24, 29 });
	upright.speed = 0.1f;

	upleft.PushBack({ 257, 91, 24, 29 });
	upleft.PushBack({ 298, 91, 24, 29 });
	upleft.PushBack({ 257, 91, 24, 29 });
	upleft.PushBack({ 215, 91, 24, 29 });
	upleft.speed = 0.1f;

	downright.PushBack({ 135,51,24,29 });
	downright.PushBack({ 176,51,24,29 });
	downright.PushBack({ 135,51,24,29 });
	downright.PushBack({ 94,51,24,29 });
	downright.speed = 0.1f;

	downleft.PushBack({ 12,91,24,29 });
	downleft.PushBack({ 331,51,24,29 });
	downleft.PushBack({ 12,91,24,29 });
	downleft.PushBack({ 51,91,24,29 });
	downleft.speed = 0.1f;
	//path.PushBack({ -0.1f, 0.0f }, 15, &right);
	
	collider = App->collision->AddCollider({ 0,0,20,29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

	dead.PushBack({ 330,92,28,27 });
	dead.PushBack({ 369,92,28,27 });
	dead.PushBack({ 409,92,28,27 });
	dead.PushBack({ 449,92,28,27 });
	dead.speed = 0.1f;
	dead.loop = false;
		
}

void Enemy_GunMen::Move()
{
	float h = sqrt(pow(2, (App->player->position.x - position.x)) + (pow(2, (App->player->position.y - position.y))));
	float angle;
	speed.x = App->player->position.x - position.x;
	speed.y = App->player->position.y - position.y;


	//position = original_pos + path.GetCurrentSpeed();
	if (animation != &dead) {
		if (speed.x != 0) {
			angle = atan2(speed.y, speed.x);

			//LOG("%f", to_degrees(angle));
		}
		else {
			angle = atan2(speed.y, speed.x + 1);
			//LOG("%f", to_degrees(angle));
		}

		if (to_degrees(angle) <= 25 && to_degrees(angle) > -25) {
			animation = &right;
		}

		else if (to_degrees(angle) <= 75 && to_degrees(angle) > 25) {
			animation = &downright;
		}

		else if (to_degrees(angle) <= 105 && to_degrees(angle) > 75) {
			animation = &front;
		}
		else if (to_degrees(angle) <= 155 && to_degrees(angle) > 105) {
			animation = &downleft;
		}
		else if ((to_degrees(angle) <= -155) || (to_degrees(angle) > 155)) {
			animation = &left;
		}
		else if (to_degrees(angle) <= -90 && to_degrees(angle) > -155) {
			animation = &upleft;
		}
		else if (to_degrees(angle) <= -25 && to_degrees(angle) > -90) {
			animation = &upright;
		}






		//*************************************** Movement

		uint Time = SDL_GetTicks();

		if (abs(App->player->position.y - position.y) < 300)
			gate[0] = true;

		if (gate[3] == true) {
			position.x--;
			position.y--;
			if (Time - (resetTime*repetitions) > (TimeUp + pathdelay))
			{
				//pathdelay = 0;
				//TimeUp = Time;
				resetTime = 13000;
				repetitions++;
				for (int i = 0; i < 4; i++) {
					gate[i] = false;
				}
			}


		}
		else if (gate[2] == true) {//down
			position.y++; //y++
			if (Time - (resetTime*repetitions) > (TimeUp + pathdelay))
			{
				pathdelay += 3000;
				gate[3] = true;
			}
		}
		else if (gate[1] == true) {//upleft
			position.x++;
			position.y--;
			if (Time - (resetTime*repetitions) > (TimeUp + pathdelay)) {
				pathdelay += 3000;
				gate[2] = true;
			}

		}
		else if (gate[0] == true) {//down

			position.y++; //y++
			pathdelay = 4000;
			if (Time - (resetTime*repetitions) > (TimeUp + pathdelay))
			{
				pathdelay += 3000;
				gate[1] = true;
			}
		}


		if (position.x >= 200) {

			position.x--;
		}
		if (position.x <= 5)
			position.x++;

		/*if (speed.x > 100)
			position.x++;
		else if (speed.x < 100)
			position.x--;
		if (speed.y > 100)
			position.y++;
		if (speed.y < 100)
			position.y--;*/
	}
	
	
}


	


void Enemy_GunMen::Shoot()
{
	uint currentTime = SDL_GetTicks();
	float angle;
	speed.x = (App->player->position.x) - position.x;
	speed.y = (App->player->position.y) - (position.y);
	h = sqrt((pow(speed.x,2) + pow(speed.y,2)));

	

	if ((currentTime > (lastTime + ENEMY_SHOOTING_SPEED)) && abs(speed.y<125) && animation!=&dead) {
	
		App->particles->enemyshoot.speed.x = (speed.x/h)*ENEMY_SHOT_SPEED;
		App->particles->enemyshoot.speed.y = (speed.y/h)*ENEMY_SHOT_SPEED;
		

		App->particles->AddParticle(App->particles->enemyshoot, position.x, position.y, COLLIDER_ENEMY_SHOT, PARTICLE_ENEMY_SHOT);


		lastTime = currentTime;
	}

}

void Enemy_GunMen::OnCollision(Collider* collider){

	if (collider->type == COLLIDER_PLAYER_SHOT && App->fade->IsFading() == false) {
		animation = &dead;
		
	}
	LOG("%d", collider->type);
}
