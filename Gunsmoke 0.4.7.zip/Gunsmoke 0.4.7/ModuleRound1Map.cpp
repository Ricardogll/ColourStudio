#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include"ModuleParticles.h"
#include"ModuleCollision.h"
#include"ModuleAudio.h"
#include"ModuleEnemies.h"

ModuleRound1map::ModuleRound1map()
{

	//mapRound1
	map1.x = 0;
	map1.y = 0;
	map1.w = 224;
	map1.h = 3200;


}

ModuleRound1map::~ModuleRound1map()
{
}


bool ModuleRound1map::Start()
{
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("gunsmoke/GunSmoke-Round1.png");
	App->particles->Enable();
	App->collision->Enable();
	App->enemies->Enable();
	App->audio->musicLoad("gunsmoke/stage1.ogg");

	
	/*App->collision->AddCollider({ 0,-80,66,348 }, COLLIDER_WALL);
	App->collision->AddCollider({ 158,-623,66,630 }, COLLIDER_WALL);*/
	App->collision->AddCollider({ 0,-80,60,348 }, COLLIDER_WALL); //primera casa izquierda
	App->collision->AddCollider({ 0,268,36,15 }, COLLIDER_WALL); //borde principio
	App->collision->AddCollider({ 0,-108,43,28 }, COLLIDER_WALL); //borde final
	App->collision->AddCollider({ 60,202,18,19 }, COLLIDER_WALL); //primera escalera
	App->collision->AddCollider({ 60,106,18,19 }, COLLIDER_WALL); //segunda escalera
	App->collision->AddCollider({ 60,44,15,18 }, COLLIDER_WALL); //tercera escalera
	App->collision->AddCollider({ 60,-54,20,19 }, COLLIDER_WALL); //cuarta escalera

																  //colliders primera casa derecha	
	App->collision->AddCollider({ 164,-623,60,630 }, COLLIDER_WALL); //primera casa derecha
	App->collision->AddCollider({ 180,-660,43,37 }, COLLIDER_WALL); //borde final
	App->collision->AddCollider({ 147,-196,17,26 }, COLLIDER_WALL); //barra caballos
	App->collision->AddCollider({ 145,-150,19,19 }, COLLIDER_WALL); //primera escalera
	App->collision->AddCollider({ 145,-246,19,19 }, COLLIDER_WALL); //segunda escalera
	App->collision->AddCollider({ 145,-342,19,19 }, COLLIDER_WALL); //tercera escalera
	App->collision->AddCollider({ 148,-404,16,19 }, COLLIDER_WALL); //cuarta escalera
	App->collision->AddCollider({ 145,-502,19,19 }, COLLIDER_WALL); //quinta escalera
	App->collision->AddCollider({ 145,-598,19,19 }, COLLIDER_WALL); //sexta escalera

																	//colliders casa medio izquierda
	App->collision->AddCollider({ 0,-1935,60,1019 }, COLLIDER_WALL); //casa medio izquierda
	App->collision->AddCollider({ 0,-1972,43,37 }, COLLIDER_WALL); //borde final
	App->collision->AddCollider({ 60,-1316,17,26 }, COLLIDER_WALL); //barra caballos
	App->collision->AddCollider({ 60,-982,18,19 }, COLLIDER_WALL); //primera escalera
	App->collision->AddCollider({ 60,-1174,18,19 }, COLLIDER_WALL); //segunda escalera
	App->collision->AddCollider({ 60,-1270,18,18 }, COLLIDER_WALL); //tercera escalera
	App->collision->AddCollider({ 60,-1366,20,19 }, COLLIDER_WALL); //cuarta escalera
	App->collision->AddCollider({ 60,-1428,15,18 }, COLLIDER_WALL); //quinta escalera
	App->collision->AddCollider({ 60,-1526,18,19 }, COLLIDER_WALL); //sexta escalera
	App->collision->AddCollider({ 60,-1622,18,19 }, COLLIDER_WALL); //septima escalera
	App->collision->AddCollider({ 60,-1814,17,19 }, COLLIDER_WALL); //octava escalera
	App->collision->AddCollider({ 60,-1910,18,19 }, COLLIDER_WALL); //novena escalera


																	//colliders casa medio derecha	
	App->collision->AddCollider({ 164,-1295,60,345 }, COLLIDER_WALL); //casa medio derecha
	App->collision->AddCollider({ 187,-950,36,17 }, COLLIDER_WALL); //borde principio
	App->collision->AddCollider({ 180,-1332,43,37 }, COLLIDER_WALL); //borde final
	App->collision->AddCollider({ 145,-1014,19,19 }, COLLIDER_WALL); //primera escalera
	App->collision->AddCollider({ 148,-1076,16,18 }, COLLIDER_WALL); //segunda escalera
	App->collision->AddCollider({ 145,-1174,19,19 }, COLLIDER_WALL); //tercera escalera
	App->collision->AddCollider({ 145,-1270,19,19 }, COLLIDER_WALL); //cuarta escalera

																	 //colliders ultima casa izquierda
	App->collision->AddCollider({ 0,-2770,60,125 }, COLLIDER_WALL); //ultima casa izquierda
	App->collision->AddCollider({ 0,-2645,36,16 }, COLLIDER_WALL); //borde principio
	App->collision->AddCollider({ 60,-2756,17,26 }, COLLIDER_WALL); //barra caballos
	App->collision->AddCollider({ 60,-2710,18,19 }, COLLIDER_WALL); //primera escalera

																	//colliders ultima casa derecha	
	App->collision->AddCollider({ 164,-2770,60,733 }, COLLIDER_WALL); //ultima casa derecha
	App->collision->AddCollider({ 147,-2436,17,26 }, COLLIDER_WALL); //barra caballos
	App->collision->AddCollider({ 145,-2102,19,19 }, COLLIDER_WALL); //primera escalera
	App->collision->AddCollider({ 145,-2294,19,19 }, COLLIDER_WALL); //segunda escalera
	App->collision->AddCollider({ 145,-2390,19,19 }, COLLIDER_WALL); //tercera escalera
	App->collision->AddCollider({ 145,-2486,19,19 }, COLLIDER_WALL); //cuarta escalera
	App->collision->AddCollider({ 145,-2582,19,19 }, COLLIDER_WALL); //quinta escalera
	App->collision->AddCollider({ 145,-2678,19,19 }, COLLIDER_WALL); //sexta escalera
	App->collision->AddCollider({ 145,-2770,19,15 }, COLLIDER_WALL); //septima escalera

																	 //colliders objetos
	App->collision->AddCollider({ 117,150,22,20 }, COLLIDER_WALL); //primera caja
	App->collision->AddCollider({ 98,-882,28,28 }, COLLIDER_WALL); //pozo
	App->collision->AddCollider({ 117,-1962,21,19 }, COLLIDER_WALL); //segunda caja


	App->enemies->AddEnemy(ENEMY_TYPES::GUNMEN, SCREEN_WIDTH / 2, 50);

	return ret;
}


update_status ModuleRound1map::Update()
{
	App->render->Blit(graphics, 0, -3200 + SCREEN_HEIGHT + 130, &map1, 5.5f);
	
	
	if (App->input->keyboard[SDL_SCANCODE_SPACE] == KEY_DOWN && App->fade->IsFading() == false) {
		App->fade->FadeToBlack(App->Maps1, App->Maps2);
		
		App->collision->Disable();
	}
	//App->render->camera.y += 1;
	

	return UPDATE_CONTINUE;
}

bool ModuleRound1map::CleanUp()
{
	LOG("Unloading map1");
	App->Maps1->Disable();
	App->textures->Unload(graphics);
	App->collision->Disable();
	gate2 = true;

	return true;
}