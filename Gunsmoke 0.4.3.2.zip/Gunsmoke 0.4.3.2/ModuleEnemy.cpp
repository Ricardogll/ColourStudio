#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleEnemy.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModuleCollision.h"


Collider* enemycoll;

ModuleEnemy::ModuleEnemy() {
	enemyrect.x = 0;
	enemyrect.y = 0;
	enemyrect.w = 35;
	enemyrect.h = 38;//38
	
}

ModuleEnemy::~ModuleEnemy() {}


bool ModuleEnemy::Start() {
	graphenemy = App->textures->Load("gunsmoke/Enemy1_25.png");
	posenemy.x = SCREEN_WIDTH / 2;
	posenemy.y = 0;
	enemycoll = App->collision->AddCollider({ posenemy.x,posenemy.y,35,38 }, COLLIDER_ENEMY, this);
	return true;
}


bool ModuleEnemy::CleanUp() {
	App->textures->Unload(graphenemy);
	return true;
}


update_status ModuleEnemy::Update() {
	App->render->Blit(graphenemy, posenemy.x, posenemy.y,&enemyrect, 0);

	return UPDATE_CONTINUE;
}


void ModuleEnemy::OnCollision(Collider* c1, Collider* c2) {
	App->enemy->Disable();

}