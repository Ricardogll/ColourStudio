#include "Application.h"
#include "Enemy_WindowSniperLeft.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


Enemy_WindowSniperLeft::Enemy_WindowSniperLeft(int x, int y) : Enemy(x, y) {

	left.PushBack({ 16,551,20,29 });
	left.PushBack({ 56,551,20,29 });
	left.PushBack({ 96,551,20,29 });
	left.PushBack({ 136,551,20,29 });
	left.PushBack({ 176,552,20,29 });
	left.PushBack({ 216,554,20,29 });
	left.PushBack({ 256,555,20,29 });
	left.PushBack({ 296,552,20,29 });
	left.speed = 0.1f;

	die.PushBack({ 336,552,20,29 });
	die.PushBack({ 376,552,20,29 });
	die.PushBack({ 416,554,20,29 });
	die.PushBack({ 456,555,20,29 });
	die.speed = 0.1f;

	animation = &left;
	path.PushBack({ -0.3f, 0.0f }, 15, &left);

	collider = App->collision->AddCollider({ 0,0,20,29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_WindowSniperLeft::Move()
{
	position = original_pos + path.GetCurrentSpeed();
	/*if (going_up)
	{
	if (wave > 1.0f)
	going_up = false;
	else
	wave += 0.05f;
	}
	else
	{
	if (wave < -1.0f)
	going_up = true;
	else
	wave -= 0.05f;
	}

	position.y = original_y + (0.25f * sinf(wave));
	position.x -= 1;*/
}