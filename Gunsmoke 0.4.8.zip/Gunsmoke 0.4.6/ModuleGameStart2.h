#ifndef __MODULEGAMESTART2_H__
#define __MODULEGAMESTART2_H__

#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleGameStart2 :public Module
{
public:
	ModuleGameStart2();
	~ModuleGameStart2();

	bool Start();
	update_status Update();
	bool CleanUp();



public:
	SDL_Texture* gameStart02 = nullptr;


	SDL_Rect start;
	bool gate = true;

	int cont = 0;
};




#endif// __MODULEGAMESTART1_H__
