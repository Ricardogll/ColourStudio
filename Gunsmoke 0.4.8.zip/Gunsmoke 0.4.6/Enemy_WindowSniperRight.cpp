#include "Application.h"
#include "Enemy_WindowSniperRight.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


Enemy_WindowSniperRight::Enemy_WindowSniperRight(int x, int y) : Enemy(x, y) {

	right.PushBack({ 461,615,20,29 });
	right.PushBack({ 421,615,20,29 });
	right.PushBack({ 380,615,20,29 });
	right.PushBack({ 338,615,20,29 });
	right.PushBack({ 295,616,20,29 });
	right.PushBack({ 253,619,20,29 });
	right.PushBack({ 215,619,20,29 });
	right.PushBack({ 176,616,20,29 });
	right.speed = 0.1f;

	die.PushBack({ 133,616,20,29 });
	die.PushBack({ 94,616,20,29 });
	die.PushBack({ 57,618,20,29 });
	die.PushBack({ 13,619,20,29 });
	die.speed = 0.1f;

	animation = &right;
	path.PushBack({ -0.3f, 0.0f }, 15, &right);

	collider = App->collision->AddCollider({ 0,0,20,29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_WindowSniperRight::Move()
{
	position = original_pos + path.GetCurrentSpeed();
	/*if (going_up)
	{
	if (wave > 1.0f)
	going_up = false;
	else
	wave += 0.05f;
	}
	else
	{
	if (wave < -1.0f)
	going_up = true;
	else
	wave -= 0.05f;
	}

	position.y = original_y + (0.25f * sinf(wave));
	position.x -= 1;*/
}