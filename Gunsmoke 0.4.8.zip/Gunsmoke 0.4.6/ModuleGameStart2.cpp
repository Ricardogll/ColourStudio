#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleGameStart2.h"
#include "ModulePlayer.h"


ModuleGameStart2::ModuleGameStart2() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleGameStart2::~ModuleGameStart2() {

}
bool ModuleGameStart2::Start() {
	LOG("Loading background assets");
	bool ret = true;
	gameStart02 = App->textures->Load("gunsmoke/GameStart_02.png");
	App->gameStart02->Enable();
	return ret;
}

bool ModuleGameStart2::CleanUp() {
	LOG("Unloading images");
	App->textures->Unload(gameStart02);
	App->gameStart02->Disable();
	gate = true;

	return true;
}
update_status ModuleGameStart2::Update() {

	App->render->Blit(gameStart02, 0, 0, &start);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate) {

		App->fade->FadeToBlack(this, App->Maps1, 1);
		gate = false;

	}


	return UPDATE_CONTINUE;
}