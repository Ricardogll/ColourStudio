#include "Application.h"
#include "Enemy_Bomber.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


Enemy_Bomber::Enemy_Bomber(int x, int y) : Enemy(x, y) {

	//angles=DistanceAngles(...
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 333,129,20,29 });
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 412,129,20,29 });
	front.speed = 0.1f;

	bomb.PushBack({ 456,128,20,29 });
	bomb.PushBack({ 13,169,20,29 });
	bomb.PushBack({ 49,168,20,29 });
	bomb.PushBack({ 92,168,20,29 });
	bomb.PushBack({ 136,169,20,29 });
	bomb.speed = 0.1f;

	die.PushBack({ 169,168,20,29 });
	die.PushBack({ 209,168,20,29 });
	die.PushBack({ 249,168,20,29 });
	die.PushBack({ 288,180,20,29 });
	die.speed = 0.1f;

	//bomb.PushBack({ })

	animation = &front;			//dependiendo del angulo con el jugador usar una animacion u otra

	path.PushBack({ 0.0f, 0.3f }, 15, &front);

	collider = App->collision->AddCollider({ 0,0,20,29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_Bomber::Move()
{
	position = original_pos + path.GetCurrentSpeed();
	/*if (going_up)
	{
	if (wave > 1.0f)
	going_up = false;
	else
	wave += 0.05f;
	}
	else
	{
	if (wave < -1.0f)
	going_up = true;
	else
	wave -= 0.05f;
	}

	position.y = original_y + (0.25f * sinf(wave));
	position.x -= 1;*/
}