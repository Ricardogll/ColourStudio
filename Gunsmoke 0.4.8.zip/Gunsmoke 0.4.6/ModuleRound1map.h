#ifndef _ModuleRound1map_H_
#define _ModuleRound1map_H_
#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleRound1map : public Module
{
public:
	ModuleRound1map();
	~ModuleRound1map();

	bool Start();
	update_status Update();
	bool CleanUp();
	 
public:

	SDL_Texture* graphics = nullptr;
	SDL_Texture* hud = nullptr;
	SDL_Rect map1;
	bool gate2 = true;
};

#endif