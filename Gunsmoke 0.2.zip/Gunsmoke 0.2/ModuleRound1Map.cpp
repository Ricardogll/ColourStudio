#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"

ModuleRound1map::ModuleRound1map()
{

	//mapRound1
	map1.x = 0;
	map1.y = 0;
	map1.w = 224;
	map1.h = 3200;


}

ModuleRound1map::~ModuleRound1map()
{
}


bool ModuleRound1map::Start()
{
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("GunSmoke-Round1.png");
	App->Maps2->Enable();
	return ret;
}


update_status ModuleRound1map::Update()
{
	App->render->Blit(graphics, 0, -3200 + SCREEN_HEIGHT + 130, &map1, 5.5f);
	
	
	if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate2) {
		App->fade->FadeToBlack(this, App->Maps2, 3);
		gate2=false;
	}
	

	return UPDATE_CONTINUE;
}

bool ModuleRound1map::CleanUp()
{
	LOG("Unloading map1");
	App->Maps1->Disable();
	gate2 = true;

	return true;
}