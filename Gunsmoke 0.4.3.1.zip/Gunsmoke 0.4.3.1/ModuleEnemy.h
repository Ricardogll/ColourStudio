#ifndef __ModuleEnemy_H__
#define __ModuleEnemy_H__



#include "Module.h"
#include "Globals.h"
#include "p2Point.h"

struct SDL_Texture;
struct Collider;

class ModuleEnemy:public Module
{
public:
	ModuleEnemy();
	~ModuleEnemy();

	bool Start();
	update_status Update();
	bool CleanUp();
	void OnCollision(Collider* c1, Collider* c2);

public:
	SDL_Texture* graphenemy = nullptr;
	iPoint posenemy;
	SDL_Rect enemyrect;
};

#endif // !__ModuleEnemy_H__

