#ifndef __ModulePlayer_H__
#define __ModulePlayer_H__

#include "Module.h"
#include "Animation.h"
#include "p2Point.h"

struct SDL_Texture;
struct Mix_Chunk;

class ModulePlayer : public Module
{
public:
	ModulePlayer();
	~ModulePlayer();

	bool Start();
	update_status Update();
	bool CleanUp();
	void OnCollision(Collider* c1, Collider* c2);

public:

	SDL_Texture* graphics = nullptr;
	Animation* current_animation = nullptr;
	Collider* playercoll;
	Animation idle;
	Animation up;
	Animation down;
	Animation left;
	Animation right;
	Animation shootup;
	Animation shootright;
	Animation shootleft;
	fPoint position;
	bool destroyed = false;
	bool gate = true;
	uint lastTime = 0;
	uint currentTime;
	bool gate2 = true;
	uint shooting_speed1 = 20;
	uint shooting_speed2 = 20;
	uint shooting_speed3 = 20;
	uint scroll=0;
	uint score = 0;
	char score_text[10];
	int font_score = -1;
	bool Godmode = false;
	bool scrollgate = true;
	uint lives = 2;
	char str[10];
	char highscore[10] = { 0,0,0,0,0,0,0,0,0,0 };
	uint highestscore = 0;
	Collider* backcollider;
	Collider* topcollider;
private:
	uint bulletsound;
	unsigned short bullet;
};

#endif