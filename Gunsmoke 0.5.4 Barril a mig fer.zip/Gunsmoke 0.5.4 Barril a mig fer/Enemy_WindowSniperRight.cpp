#include "Application.h"
#include "Enemy_WindowSniperRight.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


#define ENEMY_SHOT_SPEED 2.6f
#define ENEMY_SHOOTING_SPEED 2500

Enemy_WindowSniperRight::Enemy_WindowSniperRight(int x, int y) : Enemy(x, y) {

//	bullet = App->audio->LoadSound("gunsmoke/shot3.wav");

	right.PushBack({ 461,615,20,16 });
	right.PushBack({ 421,615,20,16 });
	right.PushBack({ 380,615,20,16 });
	right.PushBack({ 338,615,20,16 });
	right.PushBack({ 295,616,20,16 });
	right.PushBack({ 253,619,20,16 });
	right.PushBack({ 215,619,20,16 });
	right.PushBack({ 176,616,20,16 });
	right.speed = 0.1f;
	right.loop = false;

	die.PushBack({ 133,616,20,16 });
	die.PushBack({ 94,616,20,16 });
	die.PushBack({ 57,618,20,16 });
	die.PushBack({ 13,619,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 13,619,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 13,619,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 13,619,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.speed = 0.1f;
	die.loop = false;
	animation = &right;


	collider = App->collision->AddCollider({ 0,0,20,16 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_WindowSniperRight::Move()
{
	
}
void Enemy_WindowSniperRight::Shoot() {

	uint currentTime = SDL_GetTicks();
	float angle;
	speed.x = (App->player->position.x) - position.x;
	speed.y = (App->player->position.y) - (position.y);
	h = sqrt((pow(speed.x, 2) + pow(speed.y, 2)));

	if ((currentTime > (lastTime + ENEMY_SHOOTING_SPEED)) && speed.y<155 && animation != &die) {
		animation->Reset();
		App->particles->enemyshoot.speed.x = (speed.x / h)*ENEMY_SHOT_SPEED;
		App->particles->enemyshoot.speed.y = (speed.y / h)*ENEMY_SHOT_SPEED;


		App->particles->AddParticle(App->particles->enemyshoot, position.x, position.y, COLLIDER_ENEMY_SHOT, PARTICLE_ENEMY_SHOT);
	//	App->audio->PlaySound(bullet, 0);

		lastTime = currentTime;
	}

}

void Enemy_WindowSniperRight::OnCollision(Collider* collider) {

	if (collider->type == COLLIDER_PLAYER_SHOT && App->fade->IsFading() == false) {
		animation = &die;

	}
}