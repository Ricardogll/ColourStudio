#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound2map.h"
#include "ModuleRound1map.h"
#include "ModuleFadeToBlack.h"
#include"ModuleInput.h"
#include "ModuleGameStart1.h"
#include"ModulePlayer.h"
#include"ModuleEndImg.h"

ModuleRound2map::ModuleRound2map()
{

	//mapRound2
	map2.x = 0;
	map2.y = 0;
	map2.w = 224;
	map2.h = 3200;


}

ModuleRound2map::~ModuleRound2map()
{
}


bool ModuleRound2map::Start()
{
	LOG("Loading background assets");
	bool ret = true;
	graphics = App->textures->Load("gunsmoke/GunSmoke-Round2.png");
	App->Maps2->Enable();
	return ret;
}


update_status ModuleRound2map::Update()
{
	App->render->Blit(graphics, 0, -3200 + SCREEN_HEIGHT + 130, &map2, 5.5f);
	if (App->input->keyboard[SDL_SCANCODE_SPACE]==KEY_DOWN && App->fade->IsFading() == false) {

		App->fade->FadeToBlack(App->Maps2, App->endimg, 3);
		gate = false;
		App->player->Disable();
	}
	return UPDATE_CONTINUE;
}

bool ModuleRound2map::CleanUp()
{
	LOG("Unloading map1");
	App->Maps2->Disable();
	gate = true;

	return true;
}