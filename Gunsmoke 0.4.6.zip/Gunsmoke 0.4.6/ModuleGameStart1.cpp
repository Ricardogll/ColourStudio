#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleGameStart1.h"
#include "ModuleGameStart2.h"
#include "ModulePlayer.h"


ModuleGameStart1::ModuleGameStart1() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleGameStart1::~ModuleGameStart1() {

}
bool ModuleGameStart1::Start() {
	LOG("Loading background assets");
	bool ret = true;
	gameStart01 = App->textures->Load("gunsmoke/GameStart_01.png");
	App->gameStart01->Enable();
	return ret;
}

bool ModuleGameStart1::CleanUp() {
	LOG("Unloading images");
	App->textures->Unload(gameStart01);
	App->gameStart01->Disable();
	gate = true;
	
	return true;
}
update_status ModuleGameStart1::Update() {
	
		App->render->Blit(gameStart01, 0, 0, &start);

		if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate) {

			App->fade->FadeToBlack(this, App->gameStart02, 1);
			gate = false;
			
		}
	
	
	return UPDATE_CONTINUE;
}