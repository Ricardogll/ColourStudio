#ifndef __APPLICATION_H__
#define __APPLICATION_H__

#include "Globals.h"

#define NUM_MODULES 16

class ModuleWindow;
class ModuleInput;
class ModuleTextures;
class ModuleRender;
class ModuleRound1map;
class ModuleRound2map;
class ModuleFadeToBlack;
class Module;
class ModuleGameStart1;
class ModuleGameStart2;
class ModuleParticles;
class ModulePlayer;
class ModuleCollision;
class ModuleEnemies;
class ModuleEndImg;
class ModuleAudio;
class ModuleFonts;

class Application
{
public:

	Module* modules[NUM_MODULES];
	ModuleWindow* window;
	ModuleRender* render;
	ModuleInput* input;
	ModuleTextures* textures;
	ModuleRound1map* Maps1;
	ModuleRound2map* Maps2;
	ModuleFadeToBlack* fade;
	ModuleGameStart1* gameStart01;
	ModuleGameStart2* gameStart02;
	ModuleParticles* particles;
	ModulePlayer* player;
	ModuleCollision* collision;
	ModuleEnemies* enemies;
	ModuleEndImg* endimg;
	ModuleAudio* audio;
	ModuleFonts* fonts;
public:

	Application();
	~Application();

	bool Init();
	update_status Update();
	bool CleanUp();

};

// Global var made extern for Application ---
extern Application* App;

#endif // __APPLICATION_H__