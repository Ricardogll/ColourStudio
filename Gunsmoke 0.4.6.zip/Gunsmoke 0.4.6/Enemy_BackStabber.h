#ifndef __ENEMY_BACKSTABBER_H__
#define __ENEMY_BACKSTABBER_H__

#include "Enemy.h"
#include "Path.h"
#include "p2Point.h"

class Enemy_BackStabber : public Enemy
{
private:
	float wave = -1.0f;
	bool going_up = true;
	int original_y = 0;
	Animation front;
	Animation right;
	Animation left;
	Animation back;
	Animation upright;
	Animation upleft;
	Animation downright;
	Animation downleft;
	Path path;
	iPoint original_pos;
	iPoint angles;
public:

	Enemy_BackStabber(int x, int y);
	void Move();
};


#endif
