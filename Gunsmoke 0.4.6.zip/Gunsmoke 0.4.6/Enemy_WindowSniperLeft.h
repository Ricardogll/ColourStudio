#ifndef __ENEMY_WINDOWSNIPERLEFT_H__
#define __ENEMY_WINDOWSNIPERLEFT_H__

#include "Enemy.h"
#include "Path.h"
#include "p2Point.h"

class Enemy_WindowSniperLeft : public Enemy
{
private:
	float wave = -1.0f;
	bool going_up = true;
	int original_y = 0;
	Animation front;
	Animation right;
	Animation left;
	Animation back;
	Animation upright;
	Animation upleft;
	Animation downright;
	Animation downleft;
	Path path;
	iPoint original_pos;
	iPoint angles;
public:

	Enemy_WindowSniperLeft(int x, int y);
	void Move();
};


#endif