#ifndef __MODULEGAMESTART1_H__
#define __MODULEGAMESTART1_H__

#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleGameStart1:public Module
{
public:
	ModuleGameStart1();
	~ModuleGameStart1();

	bool Start();
	update_status Update();
	bool CleanUp();



public:
	SDL_Texture* gameStart01 = nullptr;
	SDL_Texture* gameStart02 = nullptr;
	

	SDL_Rect start;
	bool gate = true;
	
	int cont = 0;
};




#endif// __MODULEGAMESTART1_H__