#ifndef __MODULEIMAGES_H__
#define __MODULEIMAGES_H__

#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleImages:public Module
{
public:
	ModuleImages();
	~ModuleImages();

	bool Start();
	update_status Update();
	bool CleanUp();



public:
	SDL_Texture* background = nullptr;
	

	SDL_Rect start;
	bool gate = true;
	
	int cont = 0;
};




#endif// __MODULEIMAGE_H__