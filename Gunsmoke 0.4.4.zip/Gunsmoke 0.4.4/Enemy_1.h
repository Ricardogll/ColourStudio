#ifndef __ENEMY_ENEMY1_H__
#define __ENEMY_ENEMY1_H__

#include "Enemy.h"
#include"path.h"

class Enemy_Enemy1 :public Enemy
{
private:
	Path path;
	iPoint original_pos;
	Animation front,back,left,right;

public:

	Enemy_Enemy1(int x, int y);

	void Move();
};

#endif // !__ENEMY_ENEMY1_H__
