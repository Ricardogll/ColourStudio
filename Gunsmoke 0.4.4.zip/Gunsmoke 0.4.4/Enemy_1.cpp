#include"Application.h"
#include"Enemy_1.h"
#include"ModuleCollision.h"
#include "Globals.h"

Enemy_Enemy1::Enemy_Enemy1(int x, int y) : Enemy(x, y)
{
	front.PushBack({205,39,18,27});
	front.PushBack({205,40,19,27});
	front.PushBack({285,39,19,27});
	front.speed = 0.1f;
		
}

void Enemy_Enemy1::Move()
{
	position = original_pos + path.GetCurrentSpeed();
}