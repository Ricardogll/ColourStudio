#ifndef __ENEMY_GUNMEN_H__
#define __ENEMY_GUNMEN_H__

#include "Enemy.h"
#include"Path.h"
#include "p2Point.h"

class Enemy_GunMen : public Enemy
{
private:
	float wave = -1.0f;
	bool going_up = true;
	uint lastTime = 0;
	fPoint speed;
	uint TimeUp = 0;
	/*Animation front;
	Animation right;
	Animation left;
	Animation back;
	Animation upright;
	Animation upleft;
	Animation downright;
	Animation downleft;*/
	Path path;
	iPoint original_pos;
	fPoint angles;
	
	float h;
	int pathdelay=0;
	bool gate[4] = { false,false,false,false };
	bool gateright = false;
	bool gateleft = false;
	int repetitions = 0;
	uint resetTime;
	uint lastTime2 = 0;
	
	
public:

	Enemy_GunMen(int x, int y);
	void Move();
	void Shoot();
	void OnCollision(Collider* collider);
};


#endif
