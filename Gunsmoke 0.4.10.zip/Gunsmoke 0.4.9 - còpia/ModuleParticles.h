#ifndef __MODULEPARTICLES_H__
#define __MODULEPARTICLES_H__

#include "Module.h"
#include "Animation.h"
#include "Globals.h"
#include "p2Point.h"
#include"ModuleCollision.h"
#define MAX_ACTIVE_PARTICLES 100

struct SDL_Texture;
enum PARTICLE_TYPE
{
	PARTICLE_NONE=0,
	PARTICLE_PLAYER_SHOT,
	PARTICLE_ENEMY_SHOT,
	PARTICLE_BOMB,
	PARTICLE_BOMBEXP,
	
};


struct Particle
{
	Collider* collider = nullptr;
	Animation anim;
	uint fx = 0;
	fPoint position;
	fPoint speed;
	Uint32 born = 0;
	Uint32 life = 0;
	bool fx_played = false;
	PARTICLE_TYPE particletype;

	Particle();
	Particle(const Particle& p);
	~Particle();
	bool Update();
};

class ModuleParticles : public Module
{
public:
	ModuleParticles();
	~ModuleParticles();

	bool Start();
	update_status Update();
	bool CleanUp();

	void AddParticle(const Particle& particle, int x, int y, COLLIDER_TYPE collider_type=COLLIDER_NONE, PARTICLE_TYPE particle_type=PARTICLE_NONE, Uint32 delay = 0);

	void OnCollision(Collider* c1, Collider* c2);

	// void ParticleExplode(Particle* p);
private:

	SDL_Texture* graphics = nullptr;

	Particle* active[MAX_ACTIVE_PARTICLES];
	
	Collider* bulletcoll[MAX_ACTIVE_PARTICLES];

public:

	Particle explosion;
	Particle laser;
	Particle laserleft1;
	Particle laserleft2;
	Particle laserright1;
	Particle laserright2;
	Particle playershothit;

	Particle enemyshoot;
	Particle enemyshotexp;

	Particle bomb;
	Particle bombpreexp;
	Particle bombexp;
	
	
};

#endif // __MODULEPARTICLES_H__