#include "Application.h"
#include "Enemy_Bomber.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"
#define ENEMY_SHOOTING_SPEED 5000
#define ENEMY_SHOT_SPEED 1.5f

Enemy_Bomber::Enemy_Bomber(int x, int y) : Enemy(x, y) {

	//angles=DistanceAngles(...
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 333,129,20,29 });
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 412,129,20,29 });
	front.speed = 0.1f;


	/*bomb.PushBack({ 456,128,20,29 });
	bomb.PushBack({ 13,169,20,29 });*/
	bomb.PushBack({ 49,168,29,30 });
	bomb.PushBack({ 92,168,29,30 });
	bomb.PushBack({ 136,169,29,30 });
	
	bomb.speed = 0.1f;
	
	bomb.loop = false;

	die.PushBack({ 169,168,29,30 });
	die.PushBack({ 209,168,29,30 });
	die.PushBack({ 249,168,29,30 });
	die.PushBack({ 288,180,29,30 });
	die.speed = 0.1f;
	die.loop = false;

	//bomb.PushBack({ })

	animation = &front;			//dependiendo del angulo con el jugador usar una animacion u otra

	

	collider = App->collision->AddCollider({ 0,0,22,30 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_Bomber::Move()
{
	
}

void Enemy_Bomber::Shoot() {
	
	uint currentTime = SDL_GetTicks();
	uint currentTime2 = SDL_GetTicks();
	speed.x = (App->player->position.x) - position.x;
	speed.y = (App->player->position.y) - (position.y);
	h = sqrt((pow(speed.x, 2) + pow(speed.y, 2)));

	if ((currentTime > (lastTime + ENEMY_SHOOTING_SPEED)) && (App->player->position.x == position.x && animation != &die) && (App->player->position.y>position.y) && abs(speed.y<180))
	{
		App->particles->bomb.speed.x = 0;
		App->particles->bomb.speed.y = ENEMY_SHOT_SPEED;//mirar si esta velocidad va bn

		App->particles->AddParticle(App->particles->bomb, position.x, position.y, COLLIDER_BOMB, PARTICLE_BOMB);

		lastTime = currentTime;
	}

	if(App->particles->bomb.anim.Finished())
	{
		LOG("bomb finish");
		App->particles->bomb.speed.y = 0;
		//App->particles->AddParticle(App->particles->bombexp, position.x, position.y, COLLIDER_BOMB, PARTICLE_BOMBEXP);


	}

}

void Enemy_Bomber::OnCollision(Collider* collider) {

	if (collider->type == COLLIDER_PLAYER_SHOT && App->fade->IsFading() == false) {
		animation = &die;

	}
}