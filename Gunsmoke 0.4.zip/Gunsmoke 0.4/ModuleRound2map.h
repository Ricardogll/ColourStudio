#ifndef _ModuleRound2map_H_
#define _ModuleRound2map_H_
#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleRound2map : public Module
{
public:
	ModuleRound2map();
	~ModuleRound2map();

	bool Start();
	update_status Update();
	bool CleanUp();

public:

	SDL_Texture* graphics = nullptr;
	SDL_Rect map2;
	bool gatee = true;
};

#endif