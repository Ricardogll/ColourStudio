Gunsmoke 0.3:

-We added the player. 
-The player moves when pressing WASD.
-The player shot when pressing "x".
-The player has animations when walking.
