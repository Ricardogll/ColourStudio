#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleImages.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleImages.h"
#include "ModulePlayer.h"
#include "ModuleEnemies.h"
#include"ModuleRound1map.h"
#include "ModuleEndImg.h"

ModuleEndImg::ModuleEndImg() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleEndImg::~ModuleEndImg() {

}
bool ModuleEndImg::Start() {
	LOG("Loading background assets");
	bool ret = true;
	ending = App->textures->Load("gunsmoke/GameEnd_02.png");
	App->endimg->Enable();
	App->image->Disable();
	//App->enemies->Disable();
	return ret;
}

bool ModuleEndImg::CleanUp() {
	LOG("Unloading images");
	App->endimg->Disable();
	gate = true;
	return true;
}
update_status ModuleEndImg::Update() {
	
		App->render->Blit(ending, 0, 0, &start);

		if (App->input->keyboard[SDL_SCANCODE_SPACE]==KEY_DOWN && App->fade->IsFading()==false) {

			App->fade->FadeToBlack((Module*)App->endimg, (Module*)App->image);
			
		}
	
	
	return UPDATE_CONTINUE;
}