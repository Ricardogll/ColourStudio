#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleInput.h"
#include "ModuleParticles.h"
#include "ModuleRender.h"
#include "ModulePlayer.h"
#include"ModuleCollision.h"
#include"ModuleAudio.h"
// Reference at https://www.youtube.com/watch?v=OEhmUuehGOA
Collider* playercoll;

ModulePlayer::ModulePlayer()
{
	graphics = NULL;
	current_animation = NULL;

	position.x = 0;
	position.y = 0;

	// idle animation (just the ship)
	idle.PushBack({ 95, 1, 20, 27 });

	// move upwards
	up.PushBack({ 95, 1, 20, 27 });
	up.PushBack({ 134, 1, 20, 27 });
	up.PushBack({ 175, 1, 20, 27 });
	up.PushBack({ 375, 1, 20, 27 });
	up.PushBack({ 335, 1, 20, 27 });
	up.PushBack({ 295, 1, 20, 27 });
	up.PushBack({ 255, 1, 20, 27 });
	up.PushBack({ 215, 1, 20, 27 });
	up.loop = true;
	up.speed = 0.1f;

	// Move down
	down.PushBack({ 95, 1, 20, 27 });
	down.PushBack({ 134, 1, 20, 27 });
	down.PushBack({ 175, 1, 20, 27 });
	down.PushBack({ 375, 1, 20, 27 });
	down.PushBack({ 335, 1, 20, 27 });
	down.PushBack({ 295, 1, 20, 27 });
	down.PushBack({ 255, 1, 20, 27 });
	down.PushBack({ 215, 1, 20, 27 });
	down.loop = true;
	down.speed = 0.1f;

	right.PushBack({ 17,40,20,27 });
	right.PushBack({ 56,40,20,27 });
	right.PushBack({ 94,40,20,27 });
	right.PushBack({ 137,40,20,27 });
	right.PushBack({ 177,40,20,27 });
	right.PushBack({ 217,40,20,27 });
	right.PushBack({ 257,40,20,27 });
	right.PushBack({ 297,40,20,27 });
	right.PushBack({ 338,40,20,27 });
	right.PushBack({ 378,40,20,27 });
	right.loop = true;
	right.speed = 0.1f;

	left.PushBack({ 17,40,20,27 });
	left.PushBack({ 56,40,20,27 });
	left.PushBack({ 94,40,20,27 });
	left.PushBack({ 137,40,20,27 });
	left.PushBack({ 177,40,20,27 });
	left.PushBack({ 217,40,20,27 });
	left.PushBack({ 257,40,20,27 });
	left.PushBack({ 297,40,20,27 });
	left.PushBack({ 338,40,20,27 });
	left.PushBack({ 378,40,20,27 });
	left.loop = true;
	left.speed = 0.1f;
}

ModulePlayer::~ModulePlayer()
{}

// Load assets
bool ModulePlayer::Start()
{
	LOG("Loading player");

	graphics = App->textures->Load("gunsmoke/Gunman.png");
	position.x = SCREEN_WIDTH/2;
	position.y = SCREEN_HEIGHT-100;
	playercoll = App->collision->AddCollider({ position.x,position.y,20,27 }, COLLIDER_PLAYER, this);
	bulletsound = App->audio->Loadeffect("gunsmoke/laser.wav");
	return true;
}

// Unload assets
bool ModulePlayer::CleanUp()
{
	LOG("Unloading player");

	App->textures->Unload(graphics);

	return true;
}

// Update: draw background
update_status ModulePlayer::Update()
{
	int speed = 1;

	if (App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_REPEAT)
	{
		position.x -= speed;
		if (current_animation != &left)
		{
			left.Reset();
			current_animation = &left;
		}
	}

	if (App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT)
	{
		position.x += speed;
		if (current_animation != &right)
		{
			right.Reset();
			current_animation = &right;
		}
	}

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
	{
		position.y += speed;
		if (current_animation != &down)
		{
			down.Reset();
			current_animation = &down;
		}
	}

	if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
	{
		position.y -= speed;
		if (current_animation != &up)
		{
			up.Reset();
			current_animation = &up;
		}
	}

	// TODO 3: Shoot lasers when the player hits SPACE

	if (App->input->keyboard[SDL_SCANCODE_B] == KEY_STATE::KEY_DOWN)
	{
		App->particles->AddParticle(App->particles->explosion, position.x, position.y + 25);
		App->particles->AddParticle(App->particles->explosion, position.x - 25, position.y, 500);
		App->particles->AddParticle(App->particles->explosion, position.x, position.y - 25, 1000);
		App->particles->AddParticle(App->particles->explosion, position.x + 25, position.y, 1500);
	}

	if (App->input->keyboard[SDL_SCANCODE_X] == KEY_STATE::KEY_DOWN) {
		App->particles->AddParticle(App->particles->laser, position.x-1, position.y);
		App->particles->AddParticle(App->particles->laser, position.x + 18, position.y);
		App->audio->Playeffect(bulletsound);
		

	}

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_IDLE
		&& App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_IDLE &&
		App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_IDLE&&
		App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_IDLE)
		current_animation = &idle;

	// Draw everything --------------------------------------
	playercoll->rect.x = position.x;
	playercoll->rect.y = position.y;

	App->render->Blit(graphics, position.x, position.y, &(current_animation->GetCurrentFrame()));

	return UPDATE_CONTINUE;
}

void ModulePlayer::OnCollision(Collider* c1, Collider* c2) {
	//poner explosiones/ir a pagina principal
	if(App->input->keyboard[SDL_SCANCODE_A] == KEY_STATE::KEY_REPEAT)
		position.x ++;

	if (App->input->keyboard[SDL_SCANCODE_D] == KEY_STATE::KEY_REPEAT)
		position.x--;

	if (App->input->keyboard[SDL_SCANCODE_S] == KEY_STATE::KEY_REPEAT)
		position.y--;

	if (App->input->keyboard[SDL_SCANCODE_W] == KEY_STATE::KEY_REPEAT)
		position.y++;
}