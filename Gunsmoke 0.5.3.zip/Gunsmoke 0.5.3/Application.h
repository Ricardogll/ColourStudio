#ifndef __APPLICATION_H__
#define __APPLICATION_H__

#include "Globals.h"

#define NUM_MODULES 15

class ModuleWindow;
class ModuleInput;
class ModuleTextures;
class ModuleRender;
class ModuleRound1map;
class ModuleFadeToBlack;
class Module;
class ModuleImages;
class ModuleParticles;
class ModulePlayer;
class ModuleCollision;
class ModuleEnemies;
class ModuleEndImg;
class ModuleAudio;
class ModuleFonts;
class ModuleImgWin;

class Application
{
public:

	Module* modules[NUM_MODULES];
	ModuleWindow* window;
	ModuleRender* render;
	ModuleInput* input;
	ModuleTextures* textures;
	ModuleRound1map* Maps1;
	ModuleFadeToBlack* fade;
	ModuleImages* image;
	ModuleParticles* particles;
	ModulePlayer* player;
	ModuleCollision* collision;
	ModuleEnemies* enemies;
	ModuleEndImg* endimg;
	ModuleAudio* audio;
	ModuleFonts* fonts;
	ModuleImgWin* imgwin;
public:

	Application();
	~Application();

	bool Init();
	update_status Update();
	bool CleanUp();

};

// Global var made extern for Application ---
extern Application* App;

#endif // __APPLICATION_H__