#ifndef __MODULEIMGWIN_H__
#define __MODULEIMGWIN_H__

#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleImgWin :public Module
{
public:
	ModuleImgWin();
	~ModuleImgWin();
	
	bool Start();
	update_status Update();
	bool CleanUp();



public:
	SDL_Texture* beggining = nullptr;
	SDL_Texture* win = nullptr;

	SDL_Rect start;
	bool gate = true;
	bool gate2 = true;
	int cont = 0;
	int font_score2 = -1;
};




#endif// __MODULEIMAGE_H__