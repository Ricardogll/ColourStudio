#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleImages.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleImages.h"
#include "ModulePlayer.h"
#include "ModuleAudio.h"
#include "ModuleEnemies.h"
#include"ModuleRound1map.h"
#include "ModuleEndImg.h"
#include "ModuleImgWin.h"
#include "ModuleFonts.h"
#include <stdio.h>

ModuleImgWin::ModuleImgWin() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleImgWin::~ModuleImgWin() {

}
bool ModuleImgWin::Start() {
	LOG("Loading background assets");
	bool ret = true;
	win = App->textures->Load("gunsmoke/Map1Win.png");
	App->imgwin->Enable();
	App->image->Disable();
	App->fonts->Enable();
	App->player->Disable();
	App->enemies->Disable();
	App->audio->musicLoad("gunsmoke/19_All_Clear.ogg");
//	App->audio->PlayMusic();
	font_score2 = App->fonts->Load("gunsmoke/Icons.png", " 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ !�?�$^.:%*#()<>��+-=|&", 1);

	return ret;
}

bool ModuleImgWin::CleanUp() {
	LOG("Unloading images");
	App->imgwin->Disable();
	App->fonts->UnLoad(font_score2);
	App->textures->Unload(win);
	
	gate = true;
	return true;
}
update_status ModuleImgWin::Update() {

	App->render->Blit(win, 0, 0, &start);

	App->fonts->BlitText(10, -13, font_score2, "GUNMAN-1 HI-SCORE");
	sprintf_s(App->player->str, "%i", App->player->score);
	App->fonts->BlitText(10, 0, font_score2, App->player->str);
	App->fonts->BlitText(81, 0, font_score2, App->player->highscore);

	if (App->input->keyboard[SDL_SCANCODE_SPACE] == KEY_DOWN && App->fade->IsFading() == false) {

		App->fade->FadeToBlack((Module*)App->imgwin, (Module*)App->image);

	}


	return UPDATE_CONTINUE;
}