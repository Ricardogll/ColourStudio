#ifndef __MODULEENDIMG_H__
#define __MODULEENDIMG_H__

#include "Module.h"
#include "Globals.h"

struct SDL_Texture;

class ModuleEndImg :public Module
{
public:
	ModuleEndImg();
	~ModuleEndImg();

	bool Start();
	update_status Update();
	bool CleanUp();



public:
	SDL_Texture* beggining = nullptr;
	SDL_Texture* ending = nullptr;

	SDL_Rect start;
	bool gate = true;
	bool gate2 = true;
	int cont = 0;
	int font_score3 = -1;
};




#endif// __MODULEIMAGE_H__