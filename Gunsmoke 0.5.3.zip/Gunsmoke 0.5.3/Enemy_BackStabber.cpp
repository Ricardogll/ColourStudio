#include "Application.h"
#include "Enemy_BackStabber.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


Enemy_BackStabber::Enemy_BackStabber(int x, int y) : Enemy(x, y) {

	//angles=DistanceAngles(...
	front.PushBack({ 16,207,20,29 });
	front.PushBack({ 450,169,20,29 });
	front.PushBack({ 411,167,20,29 });
	front.PushBack({ 372,170,20,29 });
	front.PushBack({ 336,172,20,29 });
	front.speed = 0.1f;

	die.PushBack({ 131,212,20,29 });
	die.PushBack({ 49,213,20,29 });
	die.PushBack({ 88,219,20,29 });
	die.speed = 0.1f;

	animation = &front;
	path.PushBack({ -0.3f, 0.0f }, 15, &front);

	collider = App->collision->AddCollider({ 0,0,20,29 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_BackStabber::Move()
{
	position = original_pos + path.GetCurrentSpeed();
	/*if (going_up)
	{
	if (wave > 1.0f)
	going_up = false;
	else
	wave += 0.05f;
	}
	else
	{
	if (wave < -1.0f)
	going_up = true;
	else
	wave -= 0.05f;
	}

	position.y = original_y + (0.25f * sinf(wave));
	position.x -= 1;*/
}