#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleAudio.h"
#include "ModuleFadeToBlack.h"
#include "ModuleImages.h"
#include "ModulePlayer.h"



ModuleImages::ModuleImages() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleImages::~ModuleImages() {

}
bool ModuleImages::Start() {
	LOG("Loading background assets");
	bool ret = true;
	background = App->textures->Load("gunsmoke/GameStart_14.png");
	App->image->Enable();
//	App->audio->LoadMusic("gunsmoke/02_Stage_Boss_Wanted_List.ogg");
//	App->audio->PlayMusic();
	return ret;
}

bool ModuleImages::CleanUp() {
	LOG("Unloading images");
	App->textures->Unload(background);
	App->image->Disable();
	App->audio->Disable();
	gate = true;
	
	return true;
}
update_status ModuleImages::Update() {
	
		App->render->Blit(background, 0, 0, &start);

		if (App->input->keyboard[SDL_SCANCODE_SPACE]) {

			App->fade->FadeToBlack(this, App->Maps1);
			gate = false;
			App->player->Enable();
			
		}
	
	
	return UPDATE_CONTINUE;
}