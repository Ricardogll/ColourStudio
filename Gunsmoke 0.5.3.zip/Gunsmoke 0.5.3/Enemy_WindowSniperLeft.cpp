#include "Application.h"
#include "Enemy_WindowSniperLeft.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"


#define ENEMY_SHOT_SPEED 2.6f
#define ENEMY_SHOOTING_SPEED 2500

Enemy_WindowSniperLeft::Enemy_WindowSniperLeft(int x, int y) : Enemy(x, y) {

	//bullet=App->audio->LoadSound("gunsmoke/shot3.wav");

	left.PushBack({ 16,551,20,16 });
	left.PushBack({ 56,551,20,16 });
	left.PushBack({ 96,551,20,16 });
	left.PushBack({ 136,551,20,16 });
	left.PushBack({ 176,552,20,16 });
	left.PushBack({ 216,554,20,16 });
	left.PushBack({ 256,555,20,16 });
	left.PushBack({ 296,552,20,16 });
	left.speed = 0.1f;
	left.loop = false;

	die.PushBack({ 336,552,20,16 });
	die.PushBack({ 376,552,20,16 });
	die.PushBack({ 416,554,20,16 });
	die.PushBack({ 456,555,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 456,555,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 456,555,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.PushBack({ 456,555,20,16 });
	die.PushBack({ 0,0,20,16 });
	die.speed = 0.1f;
	die.loop = false;
	animation = &left;
	

	collider = App->collision->AddCollider({ 0,0,20,16 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_WindowSniperLeft::Move()
{
	
}

void Enemy_WindowSniperLeft::Shoot() {

	uint currentTime = SDL_GetTicks();
	float angle;
	speed.x = (App->player->position.x) - position.x;
	speed.y = (App->player->position.y) - (position.y);
	h = sqrt((pow(speed.x, 2) + pow(speed.y, 2)));

	if ((currentTime > (lastTime + ENEMY_SHOOTING_SPEED)) && abs(speed.y<125) && animation != &die) {
		animation->Reset();
		App->particles->enemyshoot.speed.x = (speed.x / h)*ENEMY_SHOT_SPEED;
		App->particles->enemyshoot.speed.y = (speed.y / h)*ENEMY_SHOT_SPEED;


		App->particles->AddParticle(App->particles->enemyshoot, position.x, position.y, COLLIDER_ENEMY_SHOT, PARTICLE_ENEMY_SHOT);
	//	App->audio->PlaySound(bullet, 0);

		lastTime = currentTime;
	}

}

void Enemy_WindowSniperLeft::OnCollision(Collider* collider) {

	if (collider->type == COLLIDER_PLAYER_SHOT && App->fade->IsFading() == false) {
		animation = &die;

	}
	
}