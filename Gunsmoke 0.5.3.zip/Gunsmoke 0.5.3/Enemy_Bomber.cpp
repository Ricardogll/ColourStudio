#include "Application.h"
#include "Enemy_Bomber.h"
#include "ModuleCollision.h"
#include "Globals.h"
#include "p2Point.h"
#include "ModulePlayer.h"
#include"Enemy.h"
#include <math.h>
#include "SDL\include\SDL_timer.h"
#include"ModuleParticles.h"
#include "ModuleFadeToBlack.h"

#define ENEMY_SHOOTING_SPEED 5000
#define ENEMY_SHOT_SPEED 1.5f

Enemy_Bomber::Enemy_Bomber(int x, int y) : Enemy(x, y) {

	
	//angles=DistanceAngles(...
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 333,129,20,29 });
	front.PushBack({ 374,128,20,29 });
	front.PushBack({ 412,129,20,29 });
	front.speed = 0.1f;


	/*bomb.PushBack({ 456,128,20,29 });
	bomb.PushBack({ 13,169,20,29 });*/
	bomb.PushBack({ 49,168,29,30 });
	bomb.PushBack({ 92,168,29,30 });
	bomb.PushBack({ 136,169,29,30 });
	
	bomb.speed = 0.1f;
	
	bomb.loop = false;

	die.PushBack({ 169,168,29,30 });
	die.PushBack({ 209,168,29,30 });
	die.PushBack({ 249,168,29,30 });
	die.PushBack({ 288,180,29,30 });
	die.PushBack({ 0,0,29,30 });
	die.PushBack({ 288,180,29,30 });
	die.PushBack({ 0,0,29,30 });
	die.PushBack({ 288,180,29,30 });
	die.PushBack({ 0,0,29,30 });
	die.PushBack({ 288,180,29,30 });
	die.PushBack({ 0,0,29,30 });

	die.speed = 0.1f;
	die.loop = false;

	//bomb.PushBack({ })

	animation = &front;			//dependiendo del angulo con el jugador usar una animacion u otra

	

	collider = App->collision->AddCollider({ 0,0,22,30 }, COLLIDER_TYPE::COLLIDER_ENEMY, (Module*)App->enemies);

	original_pos.x = x;
	original_pos.y = y;

}

void Enemy_Bomber::Move()
{
	float h = sqrt(pow(2, (App->player->position.x - position.x)) + (pow(2, (App->player->position.y - position.y))));
	float angle;
	speed.x = App->player->position.x - position.x;
	speed.y = App->player->position.y - position.y;
	uint Time = SDL_GetTicks();

	if (((App->player->position.y - position.y < 220 + (Time % 100) && App->player->position.y - position.y>150 + (Time % 100))||(App->player->position.y - position.y < 150)) &&gate[0] == true ) {
		position.y--;
	}

	if (abs(App->player->position.y - position.y < 300 && animation != &die))
		gate[0] = true;
	else
		gate[0] = false; // poner estoen gunmen?

	/*if (gate[1] == true && animation != &die) {
		position.x--;
		if (Time - (resetTime*repetitions) > (TimeUp + pathdelay))
		{
			repetitions++;
			for (int i = 0; i < 2; i++) {
				gate[i] = false;
			}
		}

		else if (gate[0] == true && animation != &die) {
			position.x++;
			pathdelay = 1000 * ((Time % 3) + 1);
			if (Time - (resetTime*repetitions) > (TimeUp + pathdelay))
			{
				resetTime = (1000 * ((Time % 3) + 1)) * 2;
				pathdelay += 1000 * ((Time % 3) + 1);
				gate[1] = true;
			}
		}

	}*/
	if (gate[1] == true && animation != &die) {
		position.x++;
		
	}
	else if (gate[1] == false && animation != &die) {
		position.x--;
		
	}

	if ((Time > (lastTime2 + (2000 * ((Time % 3) + 1))) && animation != &die) ){
		gate[1] = !gate[1];
		lastTime2 = Time;
		
	}

	if (position.x >= 200 && animation != &die) {

		position.x--;
	}
	if (position.x <= 5 && animation != &die)
		position.x++;
}

void Enemy_Bomber::Shoot() {
	
	uint currentTime = SDL_GetTicks();
	uint currentTime2 = SDL_GetTicks();
	speed.x = (App->player->position.x) - position.x;
	speed.y = (App->player->position.y) - (position.y);
	h = sqrt((pow(speed.x, 2) + pow(speed.y, 2)));

	if ((currentTime > (lastTime + ENEMY_SHOOTING_SPEED)) && (App->player->position.x == position.x && animation != &die) && (App->player->position.y>position.y) && abs(speed.y<180))
	{
		App->particles->bomb.speed.x = 0;
		App->particles->bomb.speed.y = ENEMY_SHOT_SPEED;//mirar si esta velocidad va bn

		App->particles->AddParticle(App->particles->bomb, position.x, position.y, COLLIDER_BOMBPREEXP, PARTICLE_BOMB);

		lastTime = currentTime;
	}

	

}

void Enemy_Bomber::OnCollision(Collider* collider) {

	if (collider->type == COLLIDER_PLAYER_SHOT && App->fade->IsFading() == false) {
		animation = &die;

	}
}