#include "Globals.h"
#include "Application.h"
#include "ModuleTextures.h"
#include "ModuleRender.h"
#include "ModuleRound1map.h"
//#include "ModuleRound2map.h"
#include "ModuleInput.h"
#include "ModuleFadeToBlack.h"
#include "ModuleImages.h"
#include "ModulePlayer.h"

ModuleImages::ModuleImages() {
	start.x = 0;
	start.y = 0;
	start.w = SCREEN_WIDTH;
	start.h = SCREEN_HEIGHT;
}
ModuleImages::~ModuleImages() {

}
bool ModuleImages::Start() {
	LOG("Loading background assets");
	bool ret = true;
	beggining = App->textures->Load("GameStart_14.png");
	ending = App->textures->Load("GameEnd_02.png");
	App->image->Enable();
	return ret;
}

bool ModuleImages::CleanUp() {
	LOG("Unloading images");
	App->image->Disable();
	gate = true;
	gate2 = true;
	return true;
}
update_status ModuleImages::Update() {
	switch (cont) {

	case 0:
		App->render->Blit(beggining, 0, 0, &start);

		if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate) {

			App->fade->FadeToBlack(this, App->Maps1, 3);
			gate = false;
			App->player->Enable();
		}
		break;
	case 1:
		App->render->Blit(ending, 0, 0, &start);

		if (App->input->keyboard[SDL_SCANCODE_SPACE] && gate2) {

			App->fade->FadeToBlack(this, App->image, 3);
			gate2 = false;
			cont = 0;
			
		}
		break;
	}
	return UPDATE_CONTINUE;
}